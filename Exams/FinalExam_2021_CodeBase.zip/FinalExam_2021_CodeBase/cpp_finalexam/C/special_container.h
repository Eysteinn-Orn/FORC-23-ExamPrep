#ifndef SPECIALCONTAINER_H_4457345
#define SPECIALCONTAINER_H_4457345

#include "keyed_container.h"

struct NumericData{
    int id;
    int place;
    double amount;
};

//TODO: Implement SpecialContainer

#endif //SPECIALCONTAINER_H_4457345