#include <iostream>
#include <string.h>

//TODO: Implement compare_strings

using namespace std;

int main(){
    char str1[1024];
    char str2[1024];
    cout << "Enter a string: ";
    cin >> str1;
    cout << "Enter a string: ";
    cin >> str2;
    if(compare_strings(str1, str2)){
        cout << "The strings are identical" << endl;
    }
    return 0;
}