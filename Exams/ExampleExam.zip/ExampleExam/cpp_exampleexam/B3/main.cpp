
using namespace std;

int main(){
    read_file_and_add();
    return 0;
}