#ifndef ADDER_H_987234
#define ADDER_H_987234

class Adder{
public:
    Adder(int number);
    int add(int added);
private:
    int number;
};

#endif //ADDER_H_987234