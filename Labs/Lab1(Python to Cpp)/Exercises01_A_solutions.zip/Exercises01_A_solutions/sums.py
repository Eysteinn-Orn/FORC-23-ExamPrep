if __name__ == "__main__":
    n1 = int(input('Enter a number: '))
    n2 = int(input('Enter another number: '))
    n3 = n1 + n2
    print("The sum of " + str(n1) + " and " + str(n2) + " is " + str(n3) + ".")