#include <iostream>

using namespace std;

int main(){
    int n1;
    int n2;
    cout << "Enter a number: ";
    cin >> n1;
    cout << "Enter another number: ";
    cin >> n2;
    int n3 = n1 + n2;
    cout << "The sum of " << n1 << " and " << n2 << " is " << n3 << "." << endl;
}