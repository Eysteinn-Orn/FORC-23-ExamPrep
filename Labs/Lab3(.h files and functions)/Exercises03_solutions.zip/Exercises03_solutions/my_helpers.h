
double circumference(double radius);

bool linear_search(char array[], int value, int array_length, int &index, int &comparisons);
bool binary_search(char array[], int value, int array_length, int &index, int &comparisons);
