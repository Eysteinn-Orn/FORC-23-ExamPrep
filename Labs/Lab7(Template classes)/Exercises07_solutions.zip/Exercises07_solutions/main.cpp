#include <iostream>
#include "my_template_pair.h"

template <class T>
T calculate_sum(T a, T b){
    return a + b;
}

int main(){

}